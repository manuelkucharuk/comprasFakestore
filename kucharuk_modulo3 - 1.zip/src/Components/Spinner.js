import './Spinner.css'

const Spinner = ()=>
        <div className="loadingio-spinner-spinner-hrca49za4m">
            <div className="ldio-vjr3djw1kkp">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>


export default Spinner