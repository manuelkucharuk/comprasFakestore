
const NotFoundPage = ()=>{
    return(
        <div className='ml-4'>
            <h1>Not found</h1>
        </div>
    )
}

export default NotFoundPage